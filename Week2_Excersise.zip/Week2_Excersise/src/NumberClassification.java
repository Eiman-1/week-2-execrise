import java.util.Scanner;

public class NumberClassification {
    public static void main(String[] args) {
        // Create a Scanner object to take input from the user
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a number
        System.out.print("Enter a positive integer: ");
        int number = scanner.nextInt();

        // Close the scanner to avoid resource leak
        scanner.close();

        // Check and print the classification of the number
        if (number <= 0) {
            System.out.println("Please enter a positive integer.");
        } else {
            String classification = classifyNumber(number);
            System.out.println(number + " is a " + classification + " number.");
        }
    }

    // Method to classify a number as perfect, abundant, or deficient
    static String classifyNumber(int num) {
        int sumOfFactors = calculateAliquotSum(num);

        if (sumOfFactors == num) {
            return "perfect";
        } else if (sumOfFactors > num) {
            return "abundant";
        } else {
            return "deficient";
        }
    }

    // Method to calculate the aliquot sum of a number
    static int calculateAliquotSum(int num) {
        int sum = 1; // Initialize sum with 1 as 1 is always a factor

        for (int i = 2; i <= num / 2; i++) {
            if (num % i == 0) {
                sum += i;
            }
        }

        return sum;
    }
}