import java.util.Scanner;

public class TriangleClassifier {
    public static void main(String[] args) {
        // Create a Scanner object to take input from the user
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter the lengths of three sides of the triangle
        System.out.println("Enter the lengths of three sides of the triangle:");

        System.out.print("Side 1: ");
        double side1 = scanner.nextDouble();

        System.out.print("Side 2: ");
        double side2 = scanner.nextDouble();

        System.out.print("Side 3: ");
        double side3 = scanner.nextDouble();

        // Close the scanner to avoid resource leak
        scanner.close();

        // Check and print the type of the triangle
        String triangleType = classifyTriangle(side1, side2, side3);
        System.out.println("The triangle is " + triangleType + ".");
    }

    // Method to classify a triangle as equilateral, isosceles, or scalene
    static String classifyTriangle(double side1, double side2, double side3) {
        if (side1 <= 0 || side2 <= 0 || side3 <= 0) {
            return "invalid (lengths must be positive)";
        }

        if (side1 == side2 && side2 == side3) {
            return "equilateral";
        } else if (side1 == side2 || side1 == side3 || side2 == side3) {
            return "isosceles";
        } else {
            return "scalene";
        }
    }
}
 